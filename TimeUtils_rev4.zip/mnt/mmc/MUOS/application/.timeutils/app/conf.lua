local love = require("love")
function love.conf(t)
    t.title = "CountDown/StartWatch"
    t.version = "11.5"
end